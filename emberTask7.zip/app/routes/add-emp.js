import Route from '@ember/routing/route';

export default class AddEmpRoute extends Route {}
