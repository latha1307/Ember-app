import Route from '@ember/routing/route';

export default class LeaveRequestsRoute extends Route {}
