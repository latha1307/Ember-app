import Component from '@glimmer/component';
import { action } from '@ember/object';
import { DateTime } from 'luxon';

export default class CalendarNavWithYearButtonsComponent extends Component {


}
