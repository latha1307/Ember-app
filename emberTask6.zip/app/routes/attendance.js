import Route from '@ember/routing/route';

export default class AttendanceRoute extends Route {}
