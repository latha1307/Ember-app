import Route from '@ember/routing/route';

export default class ApplyLeaveRoute extends Route {}
